"""
房贷计算器 - 支持商业贷款/公积金贷款/组合贷
等额本息/等额本金两种还款方式
"""
from dataclasses import dataclass, field
from typing import List, Tuple
import math


@dataclass
class LoanParams:
    """贷款参数"""
    total_price: float          # 房产总价（万元）
    down_payment_ratio: float   # 首付比例（0.0-1.0），如0.3表示30%
    loan_type: str = "commercial"  # commercial=商业贷, fund=公积金, combo=组合贷
    loan_years: int = 30        # 贷款年限
    commercial_rate: float = 0.031  # 商贷年利率（2026年LPR参考）
    fund_rate: float = 0.0285   # 公积金年利率
    fund_ratio: float = 0.0     # 组合贷中公积金占比（0.0-1.0），仅combo模式
    repayment_method: str = "equal_installment"  # equal_installment=等额本息, equal_principal=等额本金


@dataclass
class RepaymentRow:
    """每月还款明细"""
    month: int          # 期数
    payment: float      # 月供（元）
    principal: float    # 本金（元）
    interest: float     # 利息（元）
    remaining: float    # 剩余本金（元）
    cumulative_interest: float = 0.0  # 累计利息


@dataclass
class MortgageResult:
    """房贷计算结果"""
    loan_amount: float              # 贷款总额（万元）
    down_payment: float             # 首付（万元）
    monthly_payment: float          # 月供（元）- 等额本息时固定
    first_month_payment: float      # 首月月供（元）- 等额本金
    last_month_payment: float       # 末月月供（元）- 等额本金
    total_interest: float           # 总利息（元）
    total_repayment: float          # 总还款额（元）
    repayment_schedule: List[RepaymentRow] = field(default_factory=list)
    details: List[dict] = field(default_factory=list)  # 多笔贷款明细（组合贷）


def calc_equal_installment(principal: float, monthly_rate: float, months: int) -> Tuple[float, float, List[RepaymentRow]]:
    """等额本息计算"""
    if monthly_rate == 0:
        monthly_payment = principal / months
        total_interest = 0
        schedule = []
        remaining = principal
        for m in range(1, months + 1):
            interest = 0
            princ = monthly_payment
            remaining -= princ
            schedule.append(RepaymentRow(
                month=m, payment=monthly_payment, principal=princ,
                interest=interest, remaining=max(remaining, 0),
                cumulative_interest=0
            ))
        return monthly_payment, total_interest, schedule

    monthly_payment = principal * monthly_rate * (1 + monthly_rate) ** months / ((1 + monthly_rate) ** months - 1)
    total_interest = monthly_payment * months - principal
    remaining = principal
    cumulative_interest = 0
    schedule = []

    for m in range(1, months + 1):
        interest = remaining * monthly_rate
        princ = monthly_payment - interest
        remaining -= princ
        cumulative_interest += interest
        schedule.append(RepaymentRow(
            month=m, payment=round(monthly_payment, 2),
            principal=round(princ, 2), interest=round(interest, 2),
            remaining=round(max(remaining, 0), 2),
            cumulative_interest=round(cumulative_interest, 2)
        ))

    return round(monthly_payment, 2), round(total_interest, 2), schedule


def calc_equal_principal(principal: float, monthly_rate: float, months: int) -> Tuple[float, float, float, List[RepaymentRow]]:
    """等额本金计算"""
    monthly_principal = principal / months
    total_interest = 0
    remaining = principal
    cumulative_interest = 0
    schedule = []

    for m in range(1, months + 1):
        interest = remaining * monthly_rate
        payment = monthly_principal + interest
        remaining -= monthly_principal
        total_interest += interest
        cumulative_interest += interest
        schedule.append(RepaymentRow(
            month=m, payment=round(payment, 2),
            principal=round(monthly_principal, 2), interest=round(interest, 2),
            remaining=round(max(remaining, 0), 2),
            cumulative_interest=round(cumulative_interest, 2)
        ))

    first_payment = monthly_principal + principal * monthly_rate
    last_payment = monthly_principal + monthly_principal * monthly_rate
    return round(first_payment, 2), round(last_payment, 2), round(total_interest, 2), schedule


def calculate_mortgage(params: LoanParams) -> MortgageResult:
    """主计算函数"""
    loan_amount = params.total_price * 10_000 * (1 - params.down_payment_ratio)  # 转为元
    down_payment = params.total_price * 10_000 * params.down_payment_ratio
    months = params.loan_years * 12

    if params.loan_type == "combo" and params.fund_ratio > 0:
        # 组合贷
        fund_amount = loan_amount * params.fund_ratio
        comm_amount = loan_amount * (1 - params.fund_ratio)
        details = []

        # 公积金部分
        fund_monthly_rate = params.fund_rate / 12
        if params.repayment_method == "equal_installment":
            fp, fi, fs = calc_equal_installment(fund_amount, fund_monthly_rate, months)
            comm_monthly_rate = params.commercial_rate / 12
            cp, ci, cs = calc_equal_installment(comm_amount, comm_monthly_rate, months)
            monthly_payment = fp + cp
            first_month = monthly_payment
            last_month = monthly_payment
            total_interest = fi + ci
        else:
            ff, fl, fi, fs = calc_equal_principal(fund_amount, fund_monthly_rate, months)
            comm_monthly_rate = params.commercial_rate / 12
            cf, cl, ci, cs = calc_equal_principal(comm_amount, comm_monthly_rate, months)
            monthly_payment = 0
            first_month = ff + cf
            last_month = fl + cl
            total_interest = fi + ci

        details.append({
            "type": "公积金贷款",
            "amount": round(fund_amount / 10_000, 2),
            "rate": params.fund_rate,
            "monthly_payment": fp if params.repayment_method == "equal_installment" else ff,
        })
        details.append({
            "type": "商业贷款",
            "amount": round(comm_amount / 10_000, 2),
            "rate": params.commercial_rate,
            "monthly_payment": cp if params.repayment_method == "equal_installment" else cf,
        })

    elif params.loan_type == "fund":
        # 纯公积金贷款
        monthly_rate = params.fund_rate / 12
        if params.repayment_method == "equal_installment":
            monthly_payment, total_interest, schedule = calc_equal_installment(loan_amount, monthly_rate, months)
            first_month = monthly_payment
            last_month = monthly_payment
        else:
            first_month, last_month, total_interest, schedule = calc_equal_principal(loan_amount, monthly_rate, months)
            monthly_payment = 0
        details = [{"type": "公积金贷款", "amount": round(loan_amount / 10_000, 2), "rate": params.fund_rate, "monthly_payment": first_month}]

    else:
        # 纯商业贷款
        monthly_rate = params.commercial_rate / 12
        if params.repayment_method == "equal_installment":
            monthly_payment, total_interest, schedule = calc_equal_installment(loan_amount, monthly_rate, months)
            first_month = monthly_payment
            last_month = monthly_payment
        else:
            first_month, last_month, total_interest, schedule = calc_equal_principal(loan_amount, monthly_rate, months)
            monthly_payment = 0
        details = [{"type": "商业贷款", "amount": round(loan_amount / 10_000, 2), "rate": params.commercial_rate, "monthly_payment": first_month}]

    total_repayment = loan_amount + total_interest

    return MortgageResult(
        loan_amount=round(loan_amount / 10_000, 2),
        down_payment=round(down_payment / 10_000, 2),
        monthly_payment=monthly_payment,
        first_month_payment=first_month,
        last_month_payment=last_month,
        total_interest=round(total_interest, 2),
        total_repayment=round(total_repayment, 2),
        repayment_schedule=schedule if params.repayment_method == "equal_installment" else [],
        details=details,
    )


def format_result(result: MortgageResult, params: LoanParams) -> str:
    """格式化输出结果"""
    method_name = "等额本息" if params.repayment_method == "equal_installment" else "等额本金"
    loan_type_name = {"commercial": "商业贷款", "fund": "公积金贷款", "combo": "组合贷款"}.get(params.loan_type, "")

    lines = []
    lines.append(f"## 房贷计算结果")
    lines.append(f"")
    lines.append(f"| 项目 | 数值 |")
    lines.append(f"|------|------|")
    lines.append(f"| 房产总价 | {params.total_price} 万元 |")
    lines.append(f"| 首付比例 | {params.down_payment_ratio * 100:.0f}%（{result.down_payment:.2f} 万元）|")
    lines.append(f"| 贷款类型 | {loan_type_name} |")
    lines.append(f"| 贷款金额 | {result.loan_amount:.2f} 万元 |")
    lines.append(f"| 贷款年限 | {params.loan_years} 年（{params.loan_years * 12} 期）|")
    lines.append(f"| 还款方式 | {method_name} |")

    for d in result.details:
        lines.append(f"| {d['type']}金额 | {d['amount']:.2f} 万元，利率 {d['rate']*100:.2f}% |")

    lines.append(f"")
    lines.append(f"### 还款摘要")
    lines.append(f"")

    if params.repayment_method == "equal_installment":
        lines.append(f"| 项目 | 数值 |")
        lines.append(f"|------|------|")
        lines.append(f"| 每月月供 | **{result.monthly_payment:,.0f} 元** |")
        lines.append(f"| 总还款额 | {result.total_repayment:,.0f} 元（{result.total_repayment/10_000:.2f} 万元）|")
        lines.append(f"| 总利息支出 | {result.total_interest:,.0f} 元（{result.total_interest/10_000:.2f} 万元）|")
        interest_ratio = result.total_interest / result.loan_amount / 10_000 * 100
        lines.append(f"| 利息占比 | {interest_ratio:.1f}% |")
    else:
        lines.append(f"| 项目 | 数值 |")
        lines.append(f"|------|------|")
        lines.append(f"| 首月月供 | **{result.first_month_payment:,.0f} 元** |")
        lines.append(f"| 末月月供 | **{result.last_month_payment:,.0f} 元** |")
        lines.append(f"| 每月递减 | 约 {(result.first_month_payment - result.last_month_payment) / (params.loan_years * 12):,.0f} 元/月 |")
        lines.append(f"| 总还款额 | {result.total_repayment:,.0f} 元（{result.total_repayment/10_000:.2f} 万元）|")
        lines.append(f"| 总利息支出 | {result.total_interest:,.0f} 元（{result.total_interest/10_000:.2f} 万元）|")

    # 每年还款摘要（等额本息时前5年）
    if params.repayment_method == "equal_installment" and result.repayment_schedule:
        lines.append(f"")
        lines.append(f"### 逐年还款明细（前10年）")
        lines.append(f"")
        lines.append(f"| 年份 | 年还款额 | 年利息 | 年本金 | 剩余本金 |")
        lines.append(f"|------|---------|--------|--------|---------|")
        for year in range(min(10, params.loan_years)):
            year_start = year * 12
            year_end = year_start + 12
            year_rows = [r for r in result.repayment_schedule if year_start < r.month <= year_end]
            if year_rows:
                year_payment = sum(r.payment for r in year_rows)
                year_interest = sum(r.interest for r in year_rows)
                year_principal = sum(r.principal for r in year_rows)
                remaining = year_rows[-1].remaining
                lines.append(f"| 第{year+1}年 | {year_payment:,.0f} 元 | {year_interest:,.0f} 元 | {year_principal:,.0f} 元 | {remaining:,.0f} 元 |")

    return "\n".join(lines)


if __name__ == "__main__":
    # 测试用例：深圳500万房产，30%首付，30年商贷，等额本息
    params = LoanParams(
        total_price=500,
        down_payment_ratio=0.3,
        loan_type="commercial",
        loan_years=30,
        commercial_rate=0.031,
        repayment_method="equal_installment"
    )
    result = calculate_mortgage(params)
    print(format_result(result, params))
