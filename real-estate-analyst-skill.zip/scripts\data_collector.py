#!/usr/bin/env python3
"""
地产购房分析 - 数据采集脚本
用于从贝壳/链家等公开网站采集楼盘基础数据。
注意：此脚本仅供学习研究使用，请遵守目标网站的 robots.txt 和使用条款。
"""

import json
import re
import sys
import time
import urllib.parse
import urllib.request
from dataclasses import dataclass, field, asdict
from typing import Optional


# ============================================================
# 数据模型
# ============================================================

@dataclass
class PropertyInfo:
    """楼盘基础信息"""
    name: str = ""
    city: str = ""
    district: str = ""
    address: str = ""
    avg_price: float = 0.0          # 均价 元/m2
    price_range: str = ""           # 价格区间 如 "15000-18000"
    total_price_range: str = ""     # 总价区间 如 "120-180万"
    developer: str = ""
    property_company: str = ""
    opening_date: str = ""          # 开盘时间
    delivery_date: str = ""         # 交付时间
    property_type: str = ""         # 住宅/公寓/别墅
    decoration: str = ""            # 毛坯/精装
    floor_ratio: float = 0.0        # 容积率
    green_rate: float = 0.0         # 绿化率
    building_count: int = 0         # 楼栋数
    household_count: int = 0        # 总户数
    parking_ratio: str = ""         # 车位比
    area_range: str = ""            # 面积段 如 "89-142 m2"
    layout_types: list = field(default_factory=list)  # 户型列表
    subway_distance: str = ""       # 地铁距离
    schools: list = field(default_factory=list)        # 对口学校
    malls: list = field(default_factory=list)   # 附近商圈
    hospitals: list = field(default_factory=list)      # 附近医院
    data_sources: dict = field(default_factory=dict)   # 数据来源记录
    listing_count: int = 0          # 在售/挂牌房源数
    recent_sold_count: int = 0      # 近期成交套数
    price_history: list = field(default_factory=list)  # 价格历史 [{month, price}]


@dataclass
class MarketData:
    """区域市场数据"""
    city: str = ""
    district: str = ""
    district_avg_price: float = 0.0     # 区域均价
    new_house_avg_price: float = 0.0    # 新房均价
    second_hand_avg_price: float = 0.0  # 二手房均价
    monthly_deal_count: int = 0         # 月成交套数
    inventory_months: float = 0.0       # 去化周期(月)
    listing_count: int = 0              # 二手房挂牌量
    policy_summary: str = ""            # 政策摘要
    lpr_rate: float = 0.0              # 当前LPR
    population_trend: str = ""          # 人口趋势
    land_avg_premium: str = ""          # 土拍溢价率
    data_sources: dict = field(default_factory=dict)


# ============================================================
# 搜索工具
# ============================================================

def web_search_url(query: str, num: int = 5) -> str:
    """
    构造搜索 URL（通过百度搜索）。
    返回构造好的 URL 字符串，可在浏览器中打开或通过 web_fetch 获取。
    """
    encoded = urllib.parse.quote(query)
    return f"https://www.baidu.com/s?wd={encoded}&rn={num}"


def web_search_urls_bing(query: str, num: int = 5) -> str:
    """通过 Bing 搜索"""
    encoded = urllib.parse.quote(query)
    return f"https://www.bing.com/search?q={encoded}&count={num}"


# ============================================================
# 贝壳数据采集
# ============================================================

def build_beike_search_urls(city: str, property_name: str) -> dict:
    """
    根据楼盘名称构造贝壳搜索相关的 URL 列表。
    返回各类型搜索 URL 字典。

    注意：贝壳城市子域名使用城市拼音，以下为常见映射。
    """
    # 常见城市拼音映射（可扩展）
    city_pinyin_map = {
        "北京": "bj", "上海": "sh", "广州": "gz", "深圳": "sz",
        "成都": "cd", "杭州": "hz", "武汉": "wh", "南京": "nj",
        "重庆": "cq", "天津": "tj", "苏州": "su", "西安": "xa",
        "长沙": "cs", "郑州": "zz", "合肥": "hf", "青岛": "qd",
        "昆明": "km", "贵阳": "gy", "南宁": "nn", "厦门": "xm",
        "福州": "fz", "济南": "jn", "大连": "dl", "宁波": "nb",
        "沈阳": "sy", "哈尔滨": "hrb", "长春": "cc", "无锡": "wx",
    }

    city_code = city_pinyin_map.get(city, city.lower())
    encoded_name = urllib.parse.quote(property_name)

    return {
        "楼盘搜索": f"https://{city_code}.ke.com/loupan/{encoded_name}/",
        "新房列表": f"https://{city_code}.ke.com/loupan/",
        "二手房搜索": f"https://{city_code}.ke.com/ershoufang/",
        "小区搜索": f"https://{city_code}.ke.com/xiaoqu/rs{encoded_name}/",
        "贝壳网页版搜索": web_search_url(f"{property_name} 贝壳 ke.com"),
        "链家网页版搜索": web_search_url(f"{property_name} 链家 lianjia.com"),
    }


def build_anjuke_urls(city: str, property_name: str) -> dict:
    """构造安居客搜索 URL"""
    encoded_name = urllib.parse.quote(property_name)
    return {
        "新房搜索": f"https://{city}.anjuke.com/loupan/canshu-{encoded_name}/",
        "安居客网页搜索": web_search_url(f"{property_name} 安居客 anjuke.com"),
    }


# ============================================================
# 搜索策略生成
# ============================================================

def generate_search_queries(city: str, district: str, property_name: str) -> dict:
    """
    根据楼盘/区域信息，生成完整的搜索关键词列表。
    返回按类别分组的搜索查询字典。
    """
    queries = {
        "楼盘基础信息": [
            f"{property_name} 均价 户型 面积 在售",
            f"{property_name} 开发商 物业 容积率 绿化率",
            f"{property_name} 交付时间 开盘时间 交房",
        ],
        "价格与市场": [
            f"{property_name} 价格 多少钱一平米",
            f"{city} {district} 房价 走势 2026",
            f"{city} {district} 新房 二手房 成交",
            f"{city} {district} 去化周期 库存",
        ],
        "配套与环境": [
            f"{property_name} 交通 地铁 学区 配套",
            f"{property_name} 附近 商圈 医院 公园",
            f"{property_name} 户型图 得房率 采光",
        ],
        "口碑与评价": [
            f"{property_name} 优缺点 评价 口碑",
            f"{property_name} 业主 维权 投诉",
        ],
        "政策环境": [
            f"{city} 限购 政策 2026 最新",
            f"{city} 首付比例 贷款利率 2026",
            f"{city} 公积金 贷款 政策",
        ],
        "风险排查": [
            f"{property_name} 开发商 资金 停工 延期",
            f"{property_name} 烂尾 退房 降价",
            f"{district} 土地出让 拍卖 最新",
        ],
    }

    # 如果有开发商名称，增加搜索
    queries["开发商尽调"] = [
        f"{property_name} 开发商 是谁",
    ]

    return queries


def generate_risk_queries(developer: str, property_name: str) -> list:
    """生成风险排查专用搜索"""
    queries = []
    if developer:
        queries.extend([
            f"{developer} 暴雷 债务 违约",
            f"{developer} 延期交付 烂尾 维权",
            f"{developer} 资金链 三道红线",
        ])
    queries.extend([
        f"{property_name} 质量问题 业主投诉",
        f"{property_name} 停工 延期 交付",
    ])
    return queries


# ============================================================
# 数据解析辅助
# ============================================================

def parse_price(text: str) -> Optional[float]:
    """从文本中提取房价数字（元/m2）"""
    patterns = [
        r'(\d+[\.,]?\d*)\s*元[/／](?:平|m[²2])',
        r'(?:均价|报价)[：:]\s*(\d+[\.,]?\d*)',
        r'(\d+[\.,]?\d*)\s*(?:元/平|元/㎡)',
        r'(\d{4,5})\s*元',
    ]
    for p in patterns:
        m = re.search(p, text)
        if m:
            val = m.group(1).replace(',', '')
            try:
                return float(val)
            except ValueError:
                continue
    return None


def parse_price_range(text: str) -> tuple:
    """从文本中提取价格区间"""
    m = re.search(r'(\d+[\.,]?\d*)\s*[-~到至]\s*(\d+[\.,]?\d*)', text)
    if m:
        low = float(m.group(1).replace(',', ''))
        high = float(m.group(2).replace(',', ''))
        return low, high
    return 0, 0


def parse_area(text: str) -> Optional[float]:
    """从文本中提取面积数字"""
    patterns = [
        r'(\d+[\.,]?\d*)\s*(?:平|m[²2]|㎡|平方米)',
        r'建面[约]?\s*(\d+[\.,]?\d*)',
        r'面积[：:]\s*(\d+[\.,]?\d*)',
    ]
    for p in patterns:
        m = re.search(p, text)
        if m:
            try:
                return float(m.group(1).replace(',', ''))
            except ValueError:
                continue
    return None


# ============================================================
# 报告生成辅助
# ============================================================

def build_score_color(score: float) -> str:
    """根据分数返回颜色类名"""
    if score >= 7:
        return "green"
    elif score >= 5:
        return "yellow"
    else:
        return "red"


def build_signal_badge(score: float) -> dict:
    """根据综合评分返回信号信息"""
    if score >= 8.0:
        return {"class": "buy", "color": "green", "text": "BUY - 强烈推荐买入"}
    elif score >= 6.5:
        return {"class": "buy", "color": "green", "text": "BUY - 建议买入"}
    elif score >= 5.0:
        return {"class": "hold", "color": "yellow", "text": "HOLD - 可以考虑"}
    elif score >= 3.5:
        return {"class": "hold", "color": "yellow", "text": "HOLD - 建议观望"}
    else:
        return {"class": "sell", "color": "red", "text": "SELL - 不建议"}


def risk_light_html(risk_level: str) -> str:
    """生成风险信号灯 HTML"""
    color_map = {"低": "green", "中": "yellow", "高": "red",
                 "LOW": "green", "MEDIUM": "yellow", "HIGH": "red"}
    color = color_map.get(risk_level, "green")
    return f'<div class="risk-light {color}"></div>'


# ============================================================
# 数据采集协调器
# ============================================================

def create_collection_plan(city: str, district: str = "", property_name: str = "") -> dict:
    """
    创建完整的数据采集计划。
    返回结构化的采集步骤列表。
    """
    plan = {
        "meta": {
            "city": city,
            "district": district,
            "property_name": property_name,
            "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        },
        "search_queries": {},
        "data_urls": {},
        "steps": [],
    }

    # 生成搜索关键词
    if property_name:
        plan["search_queries"] = generate_search_queries(city, district, property_name)
        plan["data_urls"]["beike"] = build_beike_search_urls(city, property_name)
        plan["data_urls"]["anjuke"] = build_anjuke_urls(city, property_name)

    # 生成采集步骤
    step_num = 1
    for category, queries in plan["search_queries"].items():
        for q in queries:
            plan["steps"].append({
                "step": step_num,
                "category": category,
                "query": q,
                "url": web_search_url(q),
                "status": "pending",
            })
            step_num += 1

    return plan


# ============================================================
# CLI 入口
# ============================================================

def main():
    print("=" * 60)
    print("  地产购房分析 - 数据采集工具")
    print("  Real Estate Property Analysis - Data Collector")
    print("=" * 60)
    print()

    if len(sys.argv) < 3:
        print("用法:")
        print(f"  python {sys.argv[0]} <城市> <楼盘名称> [区域]")
        print()
        print("示例:")
        print(f"  python {sys.argv[0]} 成都 万科城市之光 天府新区")
        print(f"  python {sys.argv[0]} 杭州 保利天悦")
        print()
        print("功能:")
        print("  1. 生成结构化的搜索关键词列表")
        print("  2. 构造贝壳/链家/安居客的搜索 URL")
        print("  3. 创建数据采集计划")
        print()
        sys.exit(1)

    city = sys.argv[1]
    property_name = sys.argv[2]
    district = sys.argv[3] if len(sys.argv) > 3 else ""

    print(f"城市: {city}")
    print(f"楼盘: {property_name}")
    print(f"区域: {district or '(未指定)'}")
    print()

    # 创建采集计划
    plan = create_collection_plan(city, district, property_name)

    # 输出贝壳 URL
    print("=" * 60)
    print("  贝壳/链家 数据 URL")
    print("=" * 60)
    for name, url in plan["data_urls"].get("beike", {}).items():
        print(f"  [{name}] {url}")

    print()
    print("=" * 60)
    print("  搜索关键词列表")
    print("=" * 60)
    for category, queries in plan["search_queries"].items():
        print(f"\n  >> {category}")
        for q in queries:
            print(f"     - {q}")

    print()
    print("=" * 60)
    print(f"  共 {len(plan['steps'])} 个搜索步骤")
    print("=" * 60)
    print()

    # 保存采集计划到 JSON
    output_file = f"collection_plan_{property_name}.json"
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(plan, f, ensure_ascii=False, indent=2)
    print(f"采集计划已保存到: {output_file}")
    print()
    print("提示: 将此 JSON 文件提供给 AI Agent，按步骤执行数据采集。")


if __name__ == "__main__":
    main()
