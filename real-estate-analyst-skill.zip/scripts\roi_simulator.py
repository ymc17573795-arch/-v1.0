"""
持有成本分析器 + 投资回报模拟器
量化房产持有成本，模拟投资回报（IRR/NPV）
"""
from dataclasses import dataclass, field
from typing import List, Dict, Tuple
import math


@dataclass
class HoldingCostParams:
    """持有成本参数"""
    total_price: float          # 房产总价（万元）
    area: float                 # 面积（平方米）
    property_fee: float = 3.0   # 物业费（元/m²/月）
    parking_fee: float = 400    # 车位费（元/月），0表示无
    heating_fee: float = 0      # 供暖费（元/采暖季），北方城市
    maintenance_fund: float = 0 # 维修基金一次性（元），交房时缴纳
    insurance: float = 0        # 房屋保险（元/年）
    opportunity_rate: float = 0.025  # 资金机会成本年化收益率（如银行理财2.5%）


@dataclass
class HoldingCostResult:
    """持有成本结果"""
    annual_cost: float          # 年持有成本（元）
    monthly_cost: float         # 月持有成本（元）
    cost_items: Dict[str, float]  # 各项成本明细
    opportunity_cost: float     # 年资金机会成本（元）
    holding_cost_rate: float    # 持有成本率 = 年持有成本 / 房产总价


@dataclass
class SimulationParams:
    """投资回报模拟参数"""
    total_price: float          # 房产总价（万元）
    down_payment_ratio: float   # 首付比例
    loan_years: int = 30
    commercial_rate: float = 0.031
    fund_rate: float = 0.0285
    loan_type: str = "commercial"
    fund_ratio: float = 0.0
    holding_years: int = 10     # 持有年限
    annual_rent: float = 0      # 年租金收入（元）
    rent_growth: float = 0.02   # 年租金增长率
    price_growth_scenarios: Dict[str, float] = field(default_factory=lambda: {
        "乐观（+5%/年）": 0.05,
        "中性（+2%/年）": 0.02,
        "悲观（-1%/年）": -0.01,
    })
    # 持有成本
    property_fee: float = 3.0
    parking_fee: float = 400
    heating_fee: float = 0
    opportunity_rate: float = 0.025


@dataclass
class ScenarioResult:
    """情景模拟结果"""
    scenario_name: str
    sale_price: float           # 卖出价格（元）
    total_rental_income: float  # 总租金收入（元）
    total_mortgage_paid: float  # 总月供支出（元）
    total_holding_cost: float   # 总持有成本（不含月供）（元）
    net_profit: float           # 净利润 = 卖出价 + 租金 - 月供 - 持有成本 - 首付
    annual_return: float        # 年化收益率（简单）
    irr: float                  # 内部收益率
    payback_year: float         # 回本年数（0表示未回本）
    cash_flows: List[float] = field(default_factory=list)  # 各年净现金流


def calc_holding_cost(params: HoldingCostParams) -> HoldingCostResult:
    """计算持有成本"""
    total_yuan = params.total_price * 10_000

    annual_property = params.property_fee * params.area * 12
    annual_parking = params.parking_fee * 12
    annual_heating = params.heating_fee
    annual_insurance = params.insurance

    # 资金机会成本：首付资金如果不买房，按理财收益率计算
    # 简化处理：按全款机会成本（保守）
    annual_opportunity = total_yuan * params.opportunity_rate

    cost_items = {
        "物业费": annual_property,
        "车位费": annual_parking,
        "供暖费": annual_heating,
        "房屋保险": annual_insurance,
        "资金机会成本": annual_opportunity,
    }

    annual_cost = sum(cost_items.values())
    monthly_cost = annual_cost / 12
    holding_cost_rate = annual_cost / total_yuan * 100

    return HoldingCostResult(
        annual_cost=round(annual_cost, 2),
        monthly_cost=round(monthly_cost, 2),
        cost_items={k: round(v, 2) for k, v in cost_items.items()},
        opportunity_cost=round(annual_opportunity, 2),
        holding_cost_rate=round(holding_cost_rate, 2),
    )


def simulate_investment(params: SimulationParams) -> List[ScenarioResult]:
    """投资回报模拟"""
    from mortgage_calculator import calculate_mortgage, LoanParams

    loan_params = LoanParams(
        total_price=params.total_price,
        down_payment_ratio=params.down_payment_ratio,
        loan_type=params.loan_type,
        loan_years=params.loan_years,
        commercial_rate=params.commercial_rate,
        fund_rate=params.fund_rate,
        fund_ratio=params.fund_ratio,
        repayment_method="equal_installment"
    )
    mortgage = calculate_mortgage(loan_params)

    holding_params = HoldingCostParams(
        total_price=params.total_price,
        area=90,  # 默认值，实际使用时覆盖
        property_fee=params.property_fee,
        parking_fee=params.parking_fee,
        heating_fee=params.heating_fee,
        opportunity_rate=params.opportunity_rate,
    )
    holding = calc_holding_cost(holding_params)

    results = []

    for scenario_name, price_growth in params.price_growth_scenarios.items():
        total_yuan = params.total_price * 10_000
        down_payment_yuan = total_yuan * params.down_payment_ratio

        # 卖出价格
        sale_price = total_yuan * ((1 + price_growth) ** params.holding_years)

        # 卖出时税费（简化：满2年免增值税，卖方个税1%）
        sell_tax = sale_price * 0.01
        net_sale = sale_price - sell_tax

        # 各年现金流
        annual_rent = params.annual_rent
        yearly_cash_flows = [-down_payment_yuan]  # 第0年：首付支出
        cumulative_cash = -down_payment_yuan
        payback_year = 0

        total_rental = 0
        total_holding = 0

        for year in range(1, params.holding_years + 1):
            current_rent = annual_rent * ((1 + params.rent_growth) ** (year - 1))
            total_rental += current_rent

            year_mortgage = mortgage.monthly_payment * 12
            year_holding = holding.annual_cost

            total_holding += year_holding

            if year < params.holding_years:
                net_flow = current_rent - year_mortgage - year_holding
            else:
                # 最后一年加上卖出收入
                net_flow = current_rent - year_mortgage - year_holding + net_sale

            yearly_cash_flows.append(net_flow)
            cumulative_cash += net_flow

            if payback_year == 0 and cumulative_cash >= 0:
                payback_year = year

        # 总月供
        years_to_calc = min(params.holding_years, params.loan_years)
        total_mortgage = mortgage.monthly_payment * 12 * years_to_calc

        # 净利润
        net_profit = net_sale + total_rental - total_mortgage - total_holding - down_payment_yuan

        # 年化收益率（简单）
        annual_return = ((net_profit + down_payment_yuan) / down_payment_yuan) ** (1 / params.holding_years) - 1 if down_payment_yuan > 0 else 0

        # IRR 计算（牛顿迭代法）
        irr = calc_irr(yearly_cash_flows)

        results.append(ScenarioResult(
            scenario_name=scenario_name,
            sale_price=round(sale_price, 2),
            total_rental_income=round(total_rental, 2),
            total_mortgage_paid=round(total_mortgage, 2),
            total_holding_cost=round(total_holding, 2),
            net_profit=round(net_profit, 2),
            annual_return=round(annual_return * 100, 2),
            irr=round(irr * 100, 2),
            payback_year=payback_year,
            cash_flows=[round(cf, 2) for cf in yearly_cash_flows],
        ))

    return results


def calc_irr(cash_flows: List[float], guess: float = 0.1, max_iter: int = 1000, tol: float = 1e-6) -> float:
    """计算内部收益率（IRR）"""
    if len(cash_flows) < 2:
        return 0.0

    rate = guess
    for _ in range(max_iter):
        npv = sum(cf / (1 + rate) ** i for i, cf in enumerate(cash_flows))
        dnpv = sum(-i * cf / (1 + rate) ** (i + 1) for i, cf in enumerate(cash_flows))
        if abs(dnpv) < 1e-12:
            break
        rate -= npv / dnpv
        if abs(npv) < tol:
            break

    return rate


def format_holding_cost(result: HoldingCostResult, params: HoldingCostParams) -> str:
    """格式化持有成本输出"""
    lines = []
    lines.append(f"## 持有成本分析")
    lines.append(f"")
    lines.append(f"| 成本项目 | 年费用 | 月均 | 占比 |")
    lines.append(f"|---------|--------|------|------|")

    total = result.annual_cost
    for name, cost in result.cost_items.items():
        pct = cost / total * 100 if total > 0 else 0
        lines.append(f"| {name} | {cost:,.0f} 元 | {cost/12:,.0f} 元 | {pct:.1f}% |")

    lines.append(f"| **合计** | **{total:,.0f} 元** | **{total/12:,.0f} 元** | **100%** |")
    lines.append(f"")
    lines.append(f"| 指标 | 数值 |")
    lines.append(f"|------|------|")
    lines.append(f"| 年持有成本率 | {result.holding_cost_rate:.2f}%（占房产总价）|")
    lines.append(f"| 年资金机会成本 | {result.opportunity_cost:,.0f} 元 |")
    lines.append(f"| 资金机会成本率 | {params.opportunity_rate*100:.1f}% |")

    return "\n".join(lines)


def format_simulation(results: List[ScenarioResult], params: SimulationParams) -> str:
    """格式化模拟结果"""
    lines = []
    lines.append(f"## 投资回报模拟")
    lines.append(f"")
    lines.append(f"| 参数 | 数值 |")
    lines.append(f"|------|------|")
    lines.append(f"| 持有年限 | {params.holding_years} 年 |")
    lines.append(f"| 年租金收入 | {params.annual_rent:,.0f} 元 |")
    lines.append(f"| 租金年增长 | {params.rent_growth*100:.0f}% |")
    lines.append(f"| 贷款类型 | {params.loan_type} |")

    lines.append(f"")
    lines.append(f"### 情景对比")
    lines.append(f"")
    lines.append(f"| 指标 | 乐观 | 中性 | 悲观 |")
    lines.append(f"|------|------|------|------|")

    for i, label in enumerate(["", "", ""]):
        pass

    for idx, r in enumerate(results):
        short_name = r.scenario_name.split("（")[0] if "（" in r.scenario_name else r.scenario_name
        if idx == 0:
            lines[lines.index("| 指标 | 乐观 | 中性 | 悲观 |")] = f"| 指标 | {short_name} |"
            break

    # 重做表头
    header = "| 指标 | " + " | ".join(r.scenario_name for r in results) + " |"
    sep = "|------|" + "|".join(["------" for _ in results]) + "|"
    lines.append(header)
    lines.append(sep)

    rows = [
        ("卖出价格", lambda r: f"{r.sale_price/10_000:,.0f} 万元"),
        ("总租金收入", lambda r: f"{r.total_rental_income/10_000:,.1f} 万元"),
        ("总月供支出", lambda r: f"{r.total_mortgage_paid/10_000:,.1f} 万元"),
        ("总持有成本", lambda r: f"{r.total_holding_cost/10_000:,.1f} 万元"),
        ("净利润", lambda r: f"**{r.net_profit/10_000:,.1f} 万元**"),
        ("年化收益率", lambda r: f"**{r.annual_return:.1f}%**"),
        ("IRR", lambda r: f"**{r.irr:.1f}%**"),
        ("回本年数", lambda r: f"第{r.payback_year}年" if r.payback_year > 0 else "未回本"),
    ]

    for label, fn in rows:
        line = f"| {label} | " + " | ".join(fn(r) for r in results) + " |"
        lines.append(line)

    # 现金流明细（中性情景）
    neutral = next((r for r in results if "中性" in r.scenario_name), results[1] if len(results) > 1 else results[0])
    lines.append(f"")
    lines.append(f"### 年度现金流明细（{neutral.scenario_name}）")
    lines.append(f"")
    lines.append(f"| 年份 | 净现金流 | 累计现金流 |")
    lines.append(f"|------|---------|-----------|")
    cumulative = 0
    for i, cf in enumerate(neutral.cash_flows):
        cumulative += cf
        if i == 0:
            lines.append(f"| 第{i}年（首付） | {cf:,.0f} 元 | {cumulative:,.0f} 元 |")
        else:
            lines.append(f"| 第{i}年 | {cf:,.0f} 元 | {cumulative:,.0f} 元 |")

    return "\n".join(lines)


if __name__ == "__main__":
    # 测试持有成本
    hc_params = HoldingCostParams(total_price=500, area=89, property_fee=3.5, parking_fee=500)
    hc_result = calc_holding_cost(hc_params)
    print(format_holding_cost(hc_result, hc_params))
    print()

    # 测试投资回报
    sim_params = SimulationParams(
        total_price=500,
        down_payment_ratio=0.3,
        loan_years=30,
        commercial_rate=0.031,
        holding_years=10,
        annual_rent=42000,
        rent_growth=0.02,
        property_fee=3.5,
        parking_fee=500,
    )
    sim_results = simulate_investment(sim_params)
    print(format_simulation(sim_results, sim_params))
