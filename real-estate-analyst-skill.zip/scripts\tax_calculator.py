"""
交易税费计算器 - 覆盖新房/二手房交易全流程税费
契税、增值税、个人所得税、印花税等
"""
from dataclasses import dataclass
from typing import List


@dataclass
class TaxParams:
    """税费计算参数"""
    total_price: float          # 成交总价（万元）
    area: float                 # 面积（平方米）
    property_type: str = "residential"  # residential=住宅, commercial=商业/公寓
    transaction_type: str = "new"       # new=新房, secondhand=二手房
    ownership_count: int = 1            # 买方家庭名下房产数量（首套=1，二套=2，三套及以上=3）
    years_owned: int = 0                # 卖方持有年限（仅二手房），0=不满2年
    only_property: bool = False         # 卖方是否满五唯一（仅二手房）
    city_tier: str = "tier1"           # tier1=一线, tier2=二线, tier3=三四线


@dataclass
class TaxItem:
    """税费条目"""
    name: str
    amount: float       # 金额（元）
    payer: str          # 买方/卖方
    note: str           # 备注
    rate: float = 0.0   # 税率


@dataclass
class TaxResult:
    """税费计算结果"""
    items: List[TaxItem]
    buyer_total: float = 0.0    # 买方总税费
    seller_total: float = 0.0   # 卖方总税费
    total_tax: float = 0.0      # 总税费
    total_cost: float = 0.0     # 到手总价（房价 + 买方税费）


def calc_deed_tax(params: TaxParams) -> TaxItem:
    """契税计算"""
    price = params.total_price * 10_000  # 转为元

    if params.property_type != "residential":
        # 非住宅（商业/公寓）：统一3%
        return TaxItem(name="契税", amount=round(price * 0.03, 2), payer="买方", note="商业/公寓契税3%", rate=0.03)

    if params.transaction_type == "new":
        # 新房契税
        if params.ownership_count == 1:
            if params.area <= 90:
                return TaxItem(name="契税", amount=round(price * 0.01, 2), payer="买方", note="首套 ≤90m² 契税1%", rate=0.01)
            elif params.area <= 140:
                return TaxItem(name="契税", amount=round(price * 0.015, 2), payer="买方", note="首套 90-140m² 契税1.5%", rate=0.015)
            else:
                return TaxItem(name="契税", amount=round(price * 0.015, 2), payer="买方", note="首套 >140m² 契税1.5%", rate=0.015)
        elif params.ownership_count == 2:
            if params.area <= 140:
                return TaxItem(name="契税", amount=round(price * 0.01, 2), payer="买方", note="二套 ≤140m² 契税1%", rate=0.01)
            else:
                return TaxItem(name="契税", amount=round(price * 0.02, 2), payer="买方", note="二套 >140m² 契税2%", rate=0.02)
        else:
            return TaxItem(name="契税", amount=round(price * 0.03, 2), payer="买方", note="三套及以上 契税3%", rate=0.03)

    else:
        # 二手房契税（2024年新政后与新房统一）
        if params.ownership_count == 1:
            if params.area <= 90:
                return TaxItem(name="契税", amount=round(price * 0.01, 2), payer="买方", note="首套 ≤90m² 契税1%", rate=0.01)
            elif params.area <= 140:
                return TaxItem(name="契税", amount=round(price * 0.015, 2), payer="买方", note="首套 90-140m² 契税1.5%", rate=0.015)
            else:
                return TaxItem(name="契税", amount=round(price * 0.015, 2), payer="买方", note="首套 >140m² 契税1.5%", rate=0.015)
        elif params.ownership_count == 2:
            if params.area <= 140:
                return TaxItem(name="契税", amount=round(price * 0.01, 2), payer="买方", note="二套 ≤140m² 契税1%", rate=0.01)
            else:
                return TaxItem(name="契税", amount=round(price * 0.02, 2), payer="买方", note="二套 >140m² 契税2%", rate=0.02)
        else:
            return TaxItem(name="契税", amount=round(price * 0.03, 2), payer="买方", note="三套及以上 契税3%", rate=0.03)


def calc_vat(params: TaxParams) -> TaxItem:
    """增值税计算（二手房）"""
    if params.transaction_type == "new":
        return TaxItem(name="增值税", amount=0, payer="卖方", note="新房免征增值税", rate=0)

    price = params.total_price * 10_000

    # 2024新政：北上广深取消非普通住宅标准后，满2年免征
    if params.years_owned >= 2:
        return TaxItem(name="增值税", amount=0, payer="卖方", note=f"持有{params.years_owned}年≥2年，免征", rate=0)

    # 不满2年
    if params.city_tier == "tier1" and params.property_type == "residential":
        # 一线城市不满2年：全额征收5.3%（含城建税等）
        return TaxItem(name="增值税及附加", amount=round(price * 0.053, 2), payer="卖方", note=f"持有{params.years_owned}年<2年，一线城市全额5.3%", rate=0.053)
    else:
        return TaxItem(name="增值税及附加", amount=round(price * 0.053, 2), payer="卖方", note=f"持有{params.years_owned}年<2年，全额5.3%", rate=0.053)


def calc_personal_income_tax(params: TaxParams) -> TaxItem:
    """个人所得税计算（二手房）"""
    if params.transaction_type == "new":
        return TaxItem(name="个人所得税", amount=0, payer="卖方", note="新房免征个税", rate=0)

    price = params.total_price * 10_000

    # 满五唯一免征
    if params.years_owned >= 5 and params.only_property:
        return TaxItem(name="个人所得税", amount=0, payer="卖方", note="满五唯一，免征个税", rate=0)

    # 普通征收：差额的20% 或 总价的1-2%（核定征收）
    # 实际交易中多采用核定征收1%
    if params.property_type == "residential":
        return TaxItem(name="个人所得税", amount=round(price * 0.01, 2), payer="卖方", note=f"持有{params.years_owned}年，核定征收1%", rate=0.01)
    else:
        return TaxItem(name="个人所得税", amount=round(price * 0.02, 2), payer="卖方", note="商业房产核定征收2%", rate=0.02)


def calc_other_fees(params: TaxParams) -> List[TaxItem]:
    """其他费用"""
    items = []

    # 印花税：2022年已减免，住宅免征
    if params.property_type != "residential":
        items.append(TaxItem(name="印花税", amount=round(params.total_price * 10_000 * 0.0005, 2), payer="买卖双方", note="商业房产印花税0.05%", rate=0.0005))
    else:
        items.append(TaxItem(name="印花税", amount=0, payer="双方", note="住宅印花税已减免", rate=0))

    # 交易手续费
    items.append(TaxItem(name="交易手续费", amount=round(params.area * 6, 2), payer="买卖双方", note=f"约{params.area}m² x 6元/m²", rate=0))

    # 不动产登记费
    items.append(TaxItem(name="不动产登记费", amount=80, payer="买方", note="住宅80元/套", rate=0))

    # 权证印花税
    items.append(TaxItem(name="权证印花税", amount=5, payer="买方", note="5元/本", rate=0))

    # 评估费（二手房贷款时需要）
    if params.transaction_type == "secondhand":
        items.append(TaxItem(name="评估费", amount=round(params.total_price * 10_000 * 0.005, 2), payer="买方", note="贷款评估费约0.5%", rate=0.005))

    # 中介费（二手房）
    if params.transaction_type == "secondhand":
        items.append(TaxItem(name="中介费", amount=round(params.total_price * 10_000 * 0.015, 2), payer="买方", note="中介费约1.5%（可议价）", rate=0.015))

    return items


def calculate_tax(params: TaxParams) -> TaxResult:
    """主计算函数"""
    items = []

    # 核心税种
    items.append(calc_deed_tax(params))
    items.append(calc_vat(params))
    items.append(calc_personal_income_tax(params))

    # 其他费用
    items.extend(calc_other_fees(params))

    buyer_total = sum(item.amount for item in items if item.payer == "买方")
    seller_total = sum(item.amount for item in items if item.payer == "卖方")
    total_tax = sum(item.amount for item in items)

    return TaxResult(
        items=items,
        buyer_total=round(buyer_total, 2),
        seller_total=round(seller_total, 2),
        total_tax=round(total_tax, 2),
        total_cost=round(params.total_price * 10_000 + buyer_total, 2),
    )


def format_result(result: TaxResult, params: TaxParams) -> str:
    """格式化输出"""
    lines = []
    type_name = "新房" if params.transaction_type == "new" else "二手房"
    own_name = {1: "首套", 2: "二套"}.get(params.ownership_count, "三套+")
    prop_name = "住宅" if params.property_type == "residential" else "商业/公寓"

    lines.append(f"## 交易税费明细")
    lines.append(f"")
    lines.append(f"| 项目 | 数值 |")
    lines.append(f"|------|------|")
    lines.append(f"| 房产类型 | {prop_name} |")
    lines.append(f"| 交易类型 | {type_name} |")
    lines.append(f"| 成交总价 | {params.total_price} 万元 |")
    lines.append(f"| 面积 | {params.area} m² |")
    lines.append(f"| 套数认定 | {own_name} |")
    if params.transaction_type == "secondhand":
        lines.append(f"| 卖方持有年限 | {params.years_owned} 年 |")
        lines.append(f"| 满五唯一 | {'是' if params.only_property else '否'} |")

    lines.append(f"")
    lines.append(f"### 税费明细")
    lines.append(f"")
    lines.append(f"| 费用项目 | 金额 | 承担方 | 备注 |")
    lines.append(f"|---------|------|--------|------|")

    for item in result.items:
        if item.amount > 0:
            lines.append(f"| {item.name} | {item.amount:,.0f} 元 | {item.payer} | {item.note} |")

    lines.append(f"")
    lines.append(f"### 费用汇总")
    lines.append(f"")
    lines.append(f"| 项目 | 金额 |")
    lines.append(f"|------|------|")
    lines.append(f"| 房产总价 | {params.total_price * 10_000:,.0f} 元 |")
    lines.append(f"| 买方税费合计 | **{result.buyer_total:,.0f} 元**（{result.buyer_total/10_000:.2f} 万元）|")
    lines.append(f"| 卖方税费合计 | {result.seller_total:,.0f} 元（{result.seller_total/10_000:.2f} 万元）|")
    lines.append(f"| **到手总价** | **{result.total_cost:,.0f} 元（{result.total_cost/10_000:.2f} 万元）** |")
    tax_ratio = result.buyer_total / (params.total_price * 10_000) * 100
    lines.append(f"| 买方税费占总价 | {tax_ratio:.1f}% |")

    return "\n".join(lines)


if __name__ == "__main__":
    # 测试用例
    params = TaxParams(
        total_price=500,
        area=89,
        transaction_type="new",
        ownership_count=1,
        property_type="residential",
    )
    result = calculate_tax(params)
    print(format_result(result, params))
